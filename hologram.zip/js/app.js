define(["angular", "socketio"], (angular, io)=>{
        var app = angular.module('hologram', []);
        app.value("base_api", "http://192.168.0.100/hologram/api/public");
        app.conn = io.connect("http://192.168.0.100:5000");
        return app;
    }
);