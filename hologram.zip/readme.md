# Hologram - Simple Chat Apps with Socket.io
-

# Tech
- Socket.io for realtime chats
- Laravel frameworks 5.4 for backend
- AngularJS for frontend

# Support
Mail me at vandorohery99@gmail.com if you need some help :D